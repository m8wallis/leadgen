<?php
/**
 * Created by PhpStorm.
 * User: marksimonds
 * Date: 1/27/16
 * Time: 8:51 AM
 */

namespace ZayconWhatCounts;


class Data
{

}